// server.js
const express = require("express");
const bodyParser = require("body-parser");
const cors = require("cors");

const app = express();
app.use(cors());
app.use(bodyParser.json());

const DEFAULT_DAYS = ["Monday","Tuesday","Wednesday","Thursday","Friday"];
const DEFAULT_PERIODS = 7;
const clone = obj => JSON.parse(JSON.stringify(obj));

app.post("/generate", (req, res) => {
  try {
    const days = (req.body.days && req.body.days.length) ? req.body.days : DEFAULT_DAYS;
    const P = req.body.periodsPerDay || DEFAULT_PERIODS;
    const classes = req.body.classes || [];
    const classSubjects = req.body.classSubjects || {};
    let teachers = req.body.teachers && req.body.teachers.length ? req.body.teachers.slice() : [];

    if (teachers.length === 0) {
      const set = new Set();
      Object.values(classSubjects).forEach(arr => {
        arr.forEach(s => set.add(s.teacher));
      });
      teachers = Array.from(set);
    }

    const teacherBusy = {};
    const teacherAssignedCount = {};
    teachers.forEach(t => {
      teacherBusy[t] = Array(days.length).fill(null).map(()=> Array(P).fill(false));
      teacherAssignedCount[t] = 0;
    });

    const timetables = {};
    classes.forEach(cls => {
      timetables[cls] = Array(days.length).fill(null).map(()=> Array(P).fill("FREE"));
    });

    let allSlots = [];
    for (const cls of classes) {
      const subs = classSubjects[cls] || [];
      subs.forEach(s => {
        const hours = Math.max(0, parseInt(s.hours) || 0);
        for (let i = 0; i < hours; i++) {
          allSlots.push({ class: cls, subject: s.subject, teacher: s.teacher });
        }
      });
    }

    function pickSlotIndexByTeacherLoad(slots) {
      let minLoad = Infinity, idx = 0;
      for (let i = 0; i < slots.length; i++) {
        const t = slots[i].teacher;
        const load = teacherAssignedCount[t] !== undefined ? teacherAssignedCount[t] : 0;
        if (load < minLoad) { minLoad = load; idx = i; }
      }
      return idx;
    }

    const warnings = [];
    let unplaced = [];

    while (allSlots.length > 0) {
      const idx = pickSlotIndexByTeacherLoad(allSlots);
      const slot = allSlots.splice(idx, 1)[0];

      let placed = false;
      for (let d = 0; d < days.length && !placed; d++) {
        for (let p = 0; p < P; p++) {
          if (timetables[slot.class][d][p] === "FREE" && !teacherBusy[slot.teacher][d][p]) {
            timetables[slot.class][d][p] = `${slot.subject} (${slot.teacher})`;
            teacherBusy[slot.teacher][d][p] = true;
            teacherAssignedCount[slot.teacher]++;
            placed = true;
            break;
          }
        }
      }

      if (!placed) unplaced.push(slot);
    }

    classes.forEach(cls => {
      for (let d = 0; d < days.length; d++) {
        const row = timetables[cls][d];
        if (!row.includes("FREE")) {
          let freed = false;
          for (let p = 0; p < P && !freed; p++) {
            const cell = row[p];
            const m = cell.match(/\((.+)\)$/);
            const tname = m ? m[1] : null;
            if (!tname) continue;

            for (let d2 = 0; d2 < days.length && !freed; d2++) {
              if (d2 === d) continue;
              for (let p2 = 0; p2 < P && !freed; p2++) {
                if (timetables[cls][d2][p2] === "FREE" && !teacherBusy[tname][d2][p2]) {
                  timetables[cls][d2][p2] = row[p];
                  timetables[cls][d][p] = "FREE";
                  teacherBusy[tname][d2][p2] = true;
                  teacherBusy[tname][d][p] = false;
                  freed = true;
                }
              }
            }
          }

          if (!freed) {
            warnings.push(`Could not ensure FREE period for ${cls} on ${days[d]}.`);
          }
        }
      }
    });

    const teacherLoad = {};
    Object.keys(teacherAssignedCount).forEach(t => teacherLoad[t] = teacherAssignedCount[t]);

    res.json({
      timetables,
      warnings,
      unplaced,
      teacherLoad,
      days,
      periodsPerDay: P
    });
  } catch (err) {
    res.status(500).json({ error: "Server error", details: err.message });
  }
});

app.use(express.static("public"));
const PORT = 4000;
app.listen(PORT, ()=> console.log("Server running on http://localhost:"+PORT));
